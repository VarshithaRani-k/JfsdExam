package com.klef.jfsd.exam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.MutationQuery;
import java.util.Scanner;

public class ClientDemo {
  public static void main(String[] args) {
   updateDepartmentPositionalParams();
    //addDepartment();
  }

  public static void addDepartment() {
    Configuration configuration = new Configuration();
    configuration.configure("hibernate.cfg.xml");
    configuration.addAnnotatedClass(Department.class);

    SessionFactory sf = configuration.buildSessionFactory();
    Session session = sf.openSession();

    Transaction t = session.beginTransaction();

    Department department = new Department();
    department.setName("Maths");
    department.setLocation("Block D");
    department.setHodName("Somaji");

    session.persist(department);
    t.commit();
    System.out.println("Department Added Successfully");

    session.close();
    sf.close();
  }

  public static void updateDepartmentPositionalParams() {
    Configuration configuration = new Configuration();
    configuration.configure("hibernate.cfg.xml");
    configuration.addAnnotatedClass(Department.class);

    SessionFactory sf = configuration.buildSessionFactory();
    Session session = sf.openSession();

    Transaction t = session.beginTransaction();

    Scanner sc = new Scanner(System.in);
    System.out.println("Enter Department ID:");
    int departmentId = sc.nextInt();
    System.out.println("Enter Department Name:");
    String departmentName = sc.next();
    System.out.println("Enter Department Location:");
    String departmentLocation = sc.next();

    String hql = "update Department set name=?1, location=?2 where departmentId=?3";
    MutationQuery qry = session.createMutationQuery(hql);
    qry.setParameter(1, departmentName);
    qry.setParameter(2, departmentLocation);
    qry.setParameter(3, departmentId);

    int n = qry.executeUpdate();

    t.commit();
    System.out.println(n + " Department(s) Updated Successfully");

    sc.close();
    session.close();
    sf.close();
  }
}

    