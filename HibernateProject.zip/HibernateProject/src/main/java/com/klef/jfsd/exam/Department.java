package com.klef.jfsd.exam;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "department")
public class Department {
	
	
	 @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @Column(name = "department_id")
	  private int departmentId;

	  @Column(name = "name")
	  private String name;

	  @Column(name = "location")
	  private String location;

	  @Column(name = "hod_name")
	  private String hodName;

	  // Constructors
	  public Department() {}

	  public Department(String name, String location, String hodName) {
	    this.name = name;
	    this.location = location;
	    this.hodName = hodName;
	  }

	  // Getters and setters
	  public int getDepartmentId() {
	    return departmentId;
	  }
	  public void setDepartmentId(int departmentId) {
		    this.departmentId = departmentId;
		  }

		  public String getName() {
		    return name;
		  }

		  public void setName(String name) {
		    this.name = name;
		  }

		  public String getLocation() {
		    return location;
		  }

		  public void setLocation(String location) {
		    this.location = location;
		  }

		  public String getHodName() {
		    return hodName;
		  }

		  public void setHodName(String hodName) {
		    this.hodName = hodName;
		  }

		  @Override
		  public String toString() {
		    return "Department{" +
		            "departmentId=" + departmentId +
		            ", name='" + name + '\'' +
		            ", location='" + location + '\'' +
		            ", hodName='" + hodName + '\'' +
		            '}';
		  }


}
